Open 0_Coincidence.lvproj
Then open and run the Coincidence(x.x).vi from within the project window.

It needs to be done in this order to get the Thorlabs servo motor to properly work.